package com.appcombo.ch341p;

import java.io.File;

final class av implements b {
    final /* synthetic */ aq a;
    private final /* synthetic */ File b;

    av(aq aqVar, File file) {
        this.a = aqVar;
        this.b = file;
    }

    public final /* bridge */ /* synthetic */ void a(Object obj) {
        ((az) obj).a(this.b);
    }
}
