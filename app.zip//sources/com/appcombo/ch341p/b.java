package com.appcombo.ch341p;

public interface b {
    void a(Object obj);
}
