package com.appcombo.ch341p;

import java.io.File;

final class aw implements b {
    final /* synthetic */ aq a;
    private final /* synthetic */ File b;

    aw(aq aqVar, File file) {
        this.a = aqVar;
        this.b = file;
    }

    public final /* bridge */ /* synthetic */ void a(Object obj) {
        ((ay) obj).a(this.b);
    }
}
