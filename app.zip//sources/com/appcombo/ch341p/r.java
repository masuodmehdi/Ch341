package com.appcombo.ch341p;

import android.content.DialogInterface;

final class r implements DialogInterface.OnClickListener {
    final /* synthetic */ ch341ActivityPlus a;

    r(ch341ActivityPlus ch341activityplus) {
        this.a = ch341activityplus;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
    }
}
