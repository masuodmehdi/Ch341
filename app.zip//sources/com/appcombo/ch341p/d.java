package com.appcombo.ch341p;

final class d implements Runnable {
    final /* synthetic */ ch341ActivityPlus a;

    d(ch341ActivityPlus ch341activityplus) {
        this.a = ch341activityplus;
    }

    public final void run() {
        this.a.z.fullScroll(130);
    }
}
