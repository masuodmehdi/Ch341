package com.appcombo.ch341p;

import android.content.DialogInterface;

final class ab implements DialogInterface.OnClickListener {
    final /* synthetic */ z a;

    ab(z zVar) {
        this.a = zVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
    }
}
