package com.appcombo.ch341p;

import java.io.File;

public interface ay {
    void a(File file);
}
