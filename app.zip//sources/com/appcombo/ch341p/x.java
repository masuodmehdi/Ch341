package com.appcombo.ch341p;

import android.view.View;

final class x implements View.OnClickListener {
    final /* synthetic */ ch341ActivityPlus a;

    x(ch341ActivityPlus ch341activityplus) {
        this.a = ch341activityplus;
    }

    public final void onClick(View view) {
        x.super.onBackPressed();
    }
}
