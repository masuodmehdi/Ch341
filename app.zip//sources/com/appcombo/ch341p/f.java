package com.appcombo.ch341p;

import android.content.DialogInterface;

final class f implements DialogInterface.OnClickListener {
    final /* synthetic */ ch341ActivityPlus a;

    f(ch341ActivityPlus ch341activityplus) {
        this.a = ch341activityplus;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
    }
}
