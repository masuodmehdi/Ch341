package com.appcombo.ch341p;

import java.io.File;

public interface az {
    void a(File file);
}
