package com.appcombo.ch341p;

import android.content.DialogInterface;

final class ad implements DialogInterface.OnClickListener {
    final /* synthetic */ ac a;

    ad(ac acVar) {
        this.a = acVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        new byte[20][0] = 0;
        this.a.a.c();
        this.a.a.b();
    }
}
