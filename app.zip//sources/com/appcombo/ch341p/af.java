package com.appcombo.ch341p;

import android.view.View;

final class af implements View.OnClickListener {
    final /* synthetic */ ch341ActivityPlus a;

    af(ch341ActivityPlus ch341activityplus) {
        this.a = ch341activityplus;
    }

    public final void onClick(View view) {
        this.a.x.setText("");
    }
}
